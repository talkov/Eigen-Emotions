document.addEventListener('DOMContentLoaded', function() {
    createAndRandomizeEmojis(50); // Create the emoji rain

    const startButton = document.getElementById('start-button');
    const menu = document.getElementById('menu');
    const recognitionContainer = document.getElementById('recognition-container');
    const voiceControls = document.getElementById('voice-controls');

    // Hide voice controls initially
    voiceControls.style.display = 'none';

    startButton.addEventListener('click', function() {
        menu.style.display = 'none';
        recognitionContainer.style.display = 'block';
        voiceControls.style.display = 'flex'; // Show voice controls after clicking the start button
//        startVideoStream();
//        setInterval(fetchPrediction, 5000); // Fetch predictions every 5 seconds
    });

    // Set up voice buttons here if they are to be shown only after recognition starts
    setupVoiceButtons();
});

document.addEventListener('DOMContentLoaded', function() {
    // Set the initial text content to "Predicting..."
    document.getElementById('prediction').textContent = "Predicting...";

    // Define a function to fetch prediction from the server
    function getPrediction() {
        fetch('/get_prediction') // Send a GET request to the server
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                // Update the prediction text with the received data
                document.getElementById('prediction').innerText = data.prediction;
            })
            .catch(error => console.error('Error fetching prediction:', error));
    }

    // Call the getPrediction function initially to display the initial prediction
    getPrediction();

    // Update the prediction every 1 second (1000 milliseconds) using setInterval
    setInterval(getPrediction, 1000);
});


function updatePrediction(prediction) {
    // Update the text content with the predicted value
    document.getElementById('prediction').textContent = prediction;
}



function createAndRandomizeEmojis(emojiCount) {
    const emojiContainer = document.getElementById('emoji-animation');
    const emojisList = ['🙂', '😭', '😡', '😮', '😐', '😂', '🤔', '😴', '😍', '😌']; // Extend this list as needed

    for (let i = 0; i < emojiCount; i++) {
        const emojiSpan = document.createElement('span');
        const randomEmoji = emojisList[Math.floor(Math.random() * emojisList.length)];
        emojiSpan.textContent = randomEmoji;
        emojiContainer.appendChild(emojiSpan);

        // Apply random properties to the emoji
        const randomPosition = Math.random() * 100;
        const randomVerticalStart = Math.random() * -20; // Start from different heights above the viewport
        const randomDelay = Math.random() * 4; // Up to 4 seconds delay
        const randomDuration = 5; // Duration is fixed to 5 seconds
        const timingFunctions = ['linear', 'ease-in', 'ease-out', 'ease-in-out'];
        const randomTimingFunction = timingFunctions[Math.floor(Math.random() * timingFunctions.length)];

        emojiSpan.style.left = `${randomPosition}vw`;
        emojiSpan.style.top = `${randomVerticalStart}vh`;
        emojiSpan.style.animation = `rainEmojis ${randomDuration}s ${randomTimingFunction} ${randomDelay}s infinite`;
    }
}


 document.addEventListener('DOMContentLoaded', function() {
    setupVoiceButtons();
});

//// Function to handle prediction response
//function handlePredictionResponse(data) {
//    // Update the prediction text with the received data
//    document.getElementById('prediction').innerText = data.prediction;
//
//    // Play audio based on the predicted emotion
//    switch (data.prediction) {
//        case 'happy':
//            document.getElementById('happyAudio').play();
//            break;
//        case 'angry':
//            document.getElementById('angryAudio').play();
//            break;
//        case 'sad':
//            document.getElementById('sadAudio').play();
//            break;
//        case 'surprised':
//            document.getElementById('surprisedAudio').play();
//            break;
//        default:
//            break;
//    }
//}

function setupVoiceButtons(prediction) {
    // Get references to the audio elements
//    fetch('/get_prediction') // Send a GET request to the server
//    .then(response => response.json()) // Parse the JSON response
//    .then(data => {
//        // Update the prediction text with the received data
//        document.getElementById('prediction').innerText = data.prediction;
//
//        // Log the prediction value to the console
//        console.log(data.prediction);
//    })
//    .catch(error => {
//        // Handle any errors that occur during the fetch request
//        console.error('Error fetching prediction:', error);
//    });
//    var audioFilename = 'why_are_you_mad.ogg';
//    var audioElement = document.getElementById('smileAudio');
//    audioElement.src = "/static/audio/" + audioFilename;

    const smileAudio = document.getElementById('smileAudio');
    const whySmileAudio = document.getElementById('whySmileAudio');
    const whyMadAudio = document.getElementById('whyMadAudio');
    const whySadAudio = document.getElementById('whySadAudio');

    // Get references to the buttons
    const smileButton = document.getElementById('smileButton');
    const whySmileButton = document.getElementById('whySmileButton');
    const whyMadButton = document.getElementById('whyMadButton');
    const whySadButton = document.getElementById('whySadButton');

    // Add event listeners to the buttons
    smileButton.addEventListener('click', function() {
        // Play the smile audio
        smileAudio.play();
    });

    whySmileButton.addEventListener('click', function() {
        // Play the whySmile audio
        whySmileAudio.play();
    });

    whyMadButton.addEventListener('click', function() {
        // Play the whyMad audio
        whyMadAudio.play();
    });

    whySadButton.addEventListener('click', function() {
        // Play the whySad audio
        whySadAudio.play();
    });
}

const fetchPredictionButton = document.getElementById('fetchPredictionButton');
fetchPredictionButton.addEventListener('click', function() {
    // Fetch the prediction from the server, appending a random query parameter to ensure uniqueness
    fetch('/get_prediction?' + new Date().getTime())
        .then(response => response.json())
        .then(data => {
            // Update the prediction text with the received data
            document.getElementById('prediction').innerText = data.prediction;
        })
        .catch(error => {
            // Handle any errors that occur during the fetch request
            console.error('Error fetching prediction:', error);
        });
});