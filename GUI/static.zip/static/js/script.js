document.addEventListener('DOMContentLoaded', function() {
    createAndRandomizeEmojis(50); // Create the emoji rain

    const startButton = document.getElementById('start-button');
    const menu = document.getElementById('menu');
    const recognitionContainer = document.getElementById('recognition-container');
    const voiceControls = document.getElementById('voice-controls');

    // Hide voice controls initially
    voiceControls.style.display = 'none';

    startButton.addEventListener('click', function() {
        menu.style.display = 'none';
        recognitionContainer.style.display = 'block';
        voiceControls.style.display = 'flex'; // Show voice controls after clicking the start button
        startVideoStream();

    });
    setupVoiceButtons(); // Setup voice buttons when DOM is fully loaded
});

document.addEventListener('DOMContentLoaded', function() {
    // Set the initial text content to "Predicting..."
    document.getElementById('prediction').textContent = "Predicting...";

    // Define a function to fetch prediction from the server
    function getPrediction() {
        fetch('/get_prediction') // Send a GET request to the server
            .then(response => response.json()) // Parse the JSON response
            .then(data => {
                // Update the prediction text with the received data
                document.getElementById('prediction').innerText = data.prediction;
                currentExpression = prediction.textContent
                updatePredictionLabel(prediction.textContent)
            })
            .catch(error => console.error('Error fetching prediction:', error));
    }

    // Call the getPrediction function initially to display the initial prediction
    getPrediction();

    // Update the prediction every 1 second (1000 milliseconds) using setInterval
    setInterval(getPrediction, 1000);


});




function createAndRandomizeEmojis(emojiCount) {
    const emojiContainer = document.getElementById('emoji-animation');
    const emojisList = ['🙂', '😭', '😡', '😮', '😐', '😂', '🤔', '😴', '😍', '😌'];
    for (let i = 0; i < emojiCount; i++) {
        const emojiSpan = document.createElement('span');
        const randomEmoji = emojisList[Math.floor(Math.random() * emojisList.length)];
        emojiSpan.textContent = randomEmoji;
        emojiContainer.appendChild(emojiSpan);

        const randomPosition = Math.random() * 100;
        const randomVerticalStart = Math.random() * -20;
        const randomDelay = Math.random() * 4;
        const randomDuration = 5;
        const timingFunctions = ['linear', 'ease-in', 'ease-out', 'ease-in-out'];
        const randomTimingFunction = timingFunctions[Math.floor(Math.random() * timingFunctions.length)];

        emojiSpan.style.left = `${randomPosition}vw`;
        emojiSpan.style.top = `${randomVerticalStart}vh`;
        emojiSpan.style.animation = `rainEmojis ${randomDuration}s ${randomTimingFunction} ${randomDelay}s infinite`;
    }
}


function createAndRandomizeEmojisMain(emojiCount) {
    const emojiContainer = document.getElementById('emoji-animation-main');
    const emojisList = ['🙂', '😭', '😡', '😮', '😐', '😂', '🤔', '😴', '😍', '😌'];
    for (let i = 0; i < emojiCount; i++) {
        const emojiSpan = document.createElement('span');
        const randomEmoji = emojisList[Math.floor(Math.random() * emojisList.length)];
        emojiSpan.textContent = randomEmoji;
        emojiContainer.appendChild(emojiSpan);

        const randomPosition = Math.random() * 100;
        const randomVerticalStart = Math.random() * -20;
        const randomDelay = Math.random() * 4;
        const randomDuration = 5;
        const timingFunctions = ['linear', 'ease-in', 'ease-out', 'ease-in-out'];
        const randomTimingFunction = timingFunctions[Math.floor(Math.random() * timingFunctions.length)];

        emojiSpan.style.left = `${randomPosition}vw`;
        emojiSpan.style.top = `${randomVerticalStart}vh`;
        emojiSpan.style.animation = `rainEmojis ${randomDuration}s ${randomTimingFunction} ${randomDelay}s infinite`;
    }
}


var currentExpression
function updatePredictionLabel(mostLikelyExpression) {
    console.log("Received prediction:", mostLikelyExpression);
    const predictionLabel = document.getElementById('prediction-label');
    const emojiMap = {
        'happy': '😊',
        'sad': '😢',
        'angry': '😠',
        'surprised': '😮',
    };
    predictionLabel.textContent = emojiMap[mostLikelyExpression] || '😐';
    console.log("Selected Emoji:", selectedEmoji);
    predictionLabel.textContent = selectedEmoji;
//    currentExpression = mostLikelyExpression
}

function startVideoStream() {
    const video = document.createElement('video');
    video.id = 'video-feed';
    video.autoplay = true;
    const videoContainer = document.querySelector('.video-container');
    videoContainer.appendChild(video);

    if (navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
                video.srcObject = stream;
            })
            .catch(function(error) {
                console.error('Error accessing the camera:', error);
            });
    }
}

function setupVoiceButtons() {
    const expressionAudioButton = document.getElementById('expressionAudioButton'); // Ensure this ID is correct
    const audioMap = {
        'happy': document.getElementById('smileAudio'),
        'sad': document.getElementById('whySadAudio'),
        'angry': document.getElementById('whyMadAudio'),
        'surprised': document.getElementById('SurprisedAudio'),
    };

    expressionAudioButton.addEventListener('click', function() {
        Object.values(audioMap).forEach(audio => {
            audio.pause(); // Stop any playing audio
            audio.currentTime = 0; // Reset audio playback position
        });

        if (audioMap[currentExpression]) {
            audioMap[currentExpression].play(); // Play the audio corresponding to the current expression
        }
    });
}


function updatePrediction(prediction) {
    // Update the text content with the predicted value
    document.getElementById('prediction').textContent = prediction;
}
